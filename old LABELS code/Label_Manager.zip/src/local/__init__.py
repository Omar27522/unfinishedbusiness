"""
Local storage package for managing label files.
"""
from .repository import LocalRepository

__all__ = ['LocalRepository']
