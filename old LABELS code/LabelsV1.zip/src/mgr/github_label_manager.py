import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import requests
import os
from PIL import Image, ImageTk
from io import BytesIO
import webbrowser
import json
import threading
import pytesseract
from datetime import datetime
import subprocess
import shutil
import tempfile
import re
import hashlib

class GitHubLabelManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Label Manager - Omar27522/Projects")
        self.root.geometry("1000x700")
        
        # Configure Tesseract path - use the installed version
        tesseract_path = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
        if os.path.exists(tesseract_path):
            pytesseract.pytesseract.tesseract_cmd = tesseract_path
        
        # Repository details
        self.repo_owner = "Omar27522"
        self.repo_name = "Projects"
        self.labels_path = "labels/files"
        self.repo_url = f"https://github.com/{self.repo_owner}/{self.repo_name}"
        
        # Setup headers for GitHub API - using unauthenticated access for public repos
        self.headers = {
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Configure root background
        self.root.configure(bg='#ecf0f1')
        
        # Local repository path
        self.local_repo_path = None
        
        # Initialize status bar with colors
        self.status_var = tk.StringVar()
        self.status_bar = tk.Label(root, textvariable=self.status_var, bd=1, 
                                 relief=tk.SUNKEN, anchor=tk.W,
                                 bg='#3498db', fg='white')  # Blue background with white text
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Initialize repository
        if not self.setup_repository():
            messagebox.showerror("Error", "Failed to initialize repository. Please ensure Git is installed.")
            root.destroy()
            return
        
        # Set window icon (GitHub icon)
        try:
            icon_url = "https://github.com/favicon.ico"
            icon_response = requests.get(icon_url)
            if icon_response.status_code == 200:
                icon_data = BytesIO(icon_response.content)
                icon_image = Image.open(icon_data)
                icon_photo = ImageTk.PhotoImage(icon_image)
                self.root.iconphoto(True, icon_photo)
        except:
            pass  # Ignore icon loading errors
        
        # Configure style
        style = ttk.Style()
        style.configure('Header.TLabel', 
                       font=('TkDefaultFont', 11),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('FileCount.TLabel', 
                       font=('TkDefaultFont', 9),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('Action.TButton', 
                       padding=5,
                       background='#3498db',
                       foreground='white')
        style.configure('Counter.TLabel', 
                       font=('TkDefaultFont', 11),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('Preview.TLabelframe', 
                       font=('TkDefaultFont', 10, 'bold'),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('FileList.TLabelframe', 
                       font=('TkDefaultFont', 10, 'bold'),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('Search.TLabel', 
                       font=('TkDefaultFont', 10, 'bold'),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        
        # Create main container with padding and background
        self.main_container = tk.Frame(root, bg='#ecf0f1', padx=10, pady=10)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # Create progress bar (hidden by default)
        self.progress_frame = tk.Frame(self.main_container, bg='#ecf0f1')
        self.progress_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(self.progress_frame, 
                                          variable=self.progress_var,
                                          mode='determinate',
                                          length=300)
        
        self.progress_label = ttk.Label(self.progress_frame, 
                                      text="",
                                      style='Header.TLabel')
        
        # Create header frame
        self.create_header_frame()
        
        # Create file list frame
        self.create_file_list()
        
        # Create preview frame
        self.create_preview_frame()
        
        # Initialize variables
        self.current_image = None
        self.files_data = []
        self.last_refresh = None
        
        # Load initial data
        self.set_status("Loading repository files...")
        self.refresh_files()

    def create_header_frame(self):
        """Create the header frame with repository info and controls"""
        header_frame = tk.Frame(self.main_container, bg='#ecf0f1')
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Repository info
        info_frame = tk.Frame(header_frame, bg='#ecf0f1')
        info_frame.pack(side=tk.LEFT)
        
        repo_label = ttk.Label(info_frame, text="GitHub Repository:",
                             style='Header.TLabel')
        repo_label.pack(side=tk.LEFT)
        
        repo_link = tk.Label(info_frame, text=self.repo_url,
                         fg='#3498db', cursor='hand2',
                         bg='#ecf0f1')
        repo_link.pack(side=tk.LEFT, padx=5)
        repo_link.bind('<Button-1>', 
                      lambda e: webbrowser.open(self.repo_url))
        
        # Last refresh time
        self.refresh_label = tk.Label(info_frame, text="",
                                  bg='#ecf0f1', fg='#2c3e50')
        self.refresh_label.pack(side=tk.LEFT, padx=20)

    def create_file_list(self):
        """Create the file list frame"""
        list_frame = ttk.LabelFrame(self.main_container, text="Label Files",
                                  style='FileList.TLabelframe')
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Create search frame
        search_frame = tk.Frame(list_frame, bg='#ecf0f1')
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Search entry
        search_label = ttk.Label(search_frame, text="Search:",
                               style='Search.TLabel')
        search_label.pack(side=tk.LEFT)
        
        self.search_var = tk.StringVar()
        self.search_var.trace('w', self.filter_files)
        
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var,
                               font=('TkDefaultFont', 11))
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # File counter
        self.file_count_label = ttk.Label(search_frame, text="0 files",
                                        style='Counter.TLabel')
        self.file_count_label.pack(side=tk.LEFT, padx=(5, 0))
        
        # Control buttons frame
        controls_frame = tk.Frame(list_frame, bg='#ecf0f1')
        controls_frame.pack(fill=tk.X, pady=5, padx=5)
        
        # Big buttons with icons
        button_height = 2
        button_width = 15
        
        refresh_btn = tk.Button(controls_frame, text="🔄 Refresh Files",
                            command=self.refresh_files,
                            bg='#3498db',
                            activebackground='#2980b9',
                            fg='white',
                            height=button_height,
                            width=button_width,
                            font=('TkDefaultFont', 10))
        refresh_btn.pack(side=tk.LEFT, padx=2)
        
        show_duplicates_btn = tk.Button(controls_frame, text="🔍 Find Duplicates",
                                    command=self.show_duplicates,
                                    bg='#e67e22',
                                    activebackground='#d35400',
                                    fg='white',
                                    height=button_height,
                                    width=button_width,
                                    font=('TkDefaultFont', 10))
        show_duplicates_btn.pack(side=tk.LEFT, padx=2)
        
        upload_btn = tk.Button(controls_frame, text="⬆️ Upload Labels",
                           command=self.upload_files,
                           bg='#2ecc71',
                           activebackground='#27ae60',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        upload_btn.pack(side=tk.LEFT, padx=2)
        
        rename_btn = tk.Button(controls_frame, text="✏️ Rename File",
                           command=self.rename_file,
                           bg='#9b59b6',
                           activebackground='#8e44ad',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        rename_btn.pack(side=tk.LEFT, padx=2)
        
        delete_btn = tk.Button(controls_frame, text="❌ Delete Selected",
                           command=self.delete_files,
                           bg='#e74c3c',
                           activebackground='#c0392b',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        delete_btn.pack(side=tk.LEFT, padx=2)
        
        # Create listbox with scrollbar
        listbox_frame = tk.Frame(list_frame)
        listbox_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.file_listbox = tk.Listbox(listbox_frame,
                                     selectmode=tk.EXTENDED,
                                     font=('TkDefaultFont', 11),
                                     bg='white',
                                     fg='#2c3e50',
                                     selectbackground='#3498db',
                                     selectforeground='white')
        self.file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(listbox_frame, orient=tk.VERTICAL,
                                command=self.file_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.file_listbox.config(yscrollcommand=scrollbar.set)
        
        # Bind selection event
        self.file_listbox.bind('<<ListboxSelect>>', self.on_select)

    def create_preview_frame(self):
        """Create the preview frame"""
        preview_frame = ttk.LabelFrame(self.main_container, text="Preview",
                                     style='Preview.TLabelframe')
        preview_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        # Create canvas for image preview
        self.preview_canvas = tk.Canvas(preview_frame, bg='white',
                                      width=400, height=400)
        self.preview_canvas.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # File info frame
        info_frame = tk.Frame(preview_frame, bg='#ecf0f1')
        info_frame.pack(fill=tk.X, pady=5)
        
        self.info_label = tk.Label(info_frame, text="", wraplength=400,
                               bg='#ecf0f1', fg='#2c3e50')
        self.info_label.pack(fill=tk.X)
        
        # Action buttons
        buttons_frame = tk.Frame(preview_frame, bg='#ecf0f1')
        buttons_frame.pack(fill=tk.X)
        
        # Download button with purple theme
        download_btn = tk.Button(buttons_frame, text="Download Labels",
                             command=self.download_labels,
                             bg='#9b59b6',  # Bright purple
                             activebackground='#8e44ad',  # Darker purple when clicked
                             fg='white',
                             relief='raised')
        download_btn.pack(side=tk.LEFT, padx=5)
        
        # Store the current preview image reference
        self.current_preview_image = None

    def set_status(self, message):
        """Update status bar message"""
        self.status_var.set(message)
        self.root.update_idletasks()

    def refresh_files(self):
        """Refresh the list of files"""
        try:
            self.show_progress(True, "Refreshing files...")
            
            # Pull latest changes from GitHub
            try:
                self.set_status("Pulling latest changes from GitHub...")
                
                # First fetch all changes
                self.git_command(["git", "fetch", "--all"], "Failed to fetch changes")
                
                # Reset to match remote
                self.git_command(["git", "reset", "--hard", "origin/main"], "Failed to reset to remote")
                
                # Pull latest changes
                self.git_command(["git", "pull", "--all"], "Failed to pull latest changes")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to sync with GitHub: {str(e)}")
                return
            
            # Get all files from the labels directory
            label_dir = os.path.join(self.local_repo_path, self.labels_path)
            if not os.path.exists(label_dir):
                self.show_progress(False)
                return
            
            # Clear current list
            self.file_listbox.delete(0, tk.END)
            
            # Get and sort all files
            files = []
            for file in os.listdir(label_dir):
                file_path = os.path.join(label_dir, file)
                if os.path.isfile(file_path):  # Only add files, not directories
                    files.append(file)
            
            files.sort(key=str.lower)
            total_files = len(files)
            
            # Add files to listbox with progress updates
            for i, file in enumerate(files):
                self.file_listbox.insert(tk.END, file)
                progress = ((i + 1) / total_files) * 100
                self.update_progress(progress, f"Loading files... ({i + 1}/{total_files})")
            
            # Update file counter
            self.update_file_counter(total_files)
            
            # Update status
            self.set_status(f"Found {total_files} files")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error refreshing files: {str(e)}")
        finally:
            self.show_progress(False)

    def update_file_counter(self, count):
        """Update the file counter in the search frame"""
        if hasattr(self, 'file_count_label'):
            self.file_count_label.config(text=f"{count} files")

    def git_command(self, command, error_message="Git command failed"):
        """Execute a git command"""
        try:
            print(f"\nExecuting Git Command: {' '.join(command)}")
            result = subprocess.run(
                command,
                cwd=self.local_repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            print(f"Git Command Output: {result.stdout}")
            return result.stdout.strip()
            
        except subprocess.CalledProcessError as e:
            print(f"\nGit Command Error:")
            print(f"Command: {' '.join(command)}")
            print(f"Exit Code: {e.returncode}")
            print(f"Stdout: {e.stdout}")
            print(f"Stderr: {e.stderr}")
            raise Exception(f"{error_message}: {e.stderr}")

    def update_file_list(self):
        """Update the listbox with files"""
        self.file_listbox.delete(0, tk.END)
        search_term = self.search_var.get().lower()
        
        displayed_files = []
        for file in self.files_data:
            if file['type'] == 'file' and file['name'].lower().endswith(('.png', '.jpg', '.jpeg')):
                if search_term in file['name'].lower():
                    displayed_files.append(file)
                    self.file_listbox.insert(tk.END, file['name'])
        
        self.update_file_counter(len(displayed_files))
    
    def filter_files(self, *args):
        """Filter files based on search term"""
        search_term = self.search_var.get().lower()
        self.file_listbox.delete(0, tk.END)
        
        # Get all files from the labels directory
        label_dir = os.path.join(self.local_repo_path, self.labels_path)
        if not os.path.exists(label_dir):
            return
        
        # Filter and display matching files
        matching_files = []
        for file in os.listdir(label_dir):
            if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                if search_term in file.lower():
                    matching_files.append(file)
        
        # Sort files
        matching_files.sort(key=str.lower)
        
        # Add matching files to listbox
        for file in matching_files:
            self.file_listbox.insert(tk.END, file)
        
        # Update file counter
        self.update_file_counter(len(matching_files))
        
        # Update status
        if search_term:
            self.set_status(f"Found {len(matching_files)} matching files")
        else:
            self.set_status("Ready")

    def on_select(self, event):
        """Handle file selection"""
        selection = self.file_listbox.curselection()
        if not selection:
            return
            
        try:
            # Get selected filename
            filename = self.file_listbox.get(selection[0])
            
            # Construct full path to the image
            image_path = os.path.join(self.local_repo_path, self.labels_path, filename)
            
            if not os.path.exists(image_path):
                print(f"Image file not found: {image_path}")
                return
            
            # Load and resize image for preview
            image = Image.open(image_path)
            
            # Calculate resize dimensions while maintaining aspect ratio
            canvas_width = self.preview_canvas.winfo_width()
            canvas_height = self.preview_canvas.winfo_height()
            
            # If canvas size is not yet set, use default dimensions
            if canvas_width <= 1:
                canvas_width = 400
            if canvas_height <= 1:
                canvas_height = 400
            
            # Calculate scaling factor
            width_ratio = canvas_width / image.width
            height_ratio = canvas_height / image.height
            scale_factor = min(width_ratio, height_ratio)
            
            # Calculate new dimensions
            new_width = int(image.width * scale_factor)
            new_height = int(image.height * scale_factor)
            
            # Resize image
            resized_image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # Convert to PhotoImage
            photo_image = ImageTk.PhotoImage(resized_image)
            
            # Clear previous image
            self.preview_canvas.delete("all")
            
            # Calculate center position
            x = (canvas_width - new_width) // 2
            y = (canvas_height - new_height) // 2
            
            # Display new image
            self.preview_canvas.create_image(x, y, anchor=tk.NW, image=photo_image)
            
            # Keep a reference to prevent garbage collection
            self.current_preview_image = photo_image
            
            # Update file info
            file_size = os.path.getsize(image_path)
            image_info = f"File: {filename}\n"
            image_info += f"Size: {file_size:,} bytes\n"
            image_info += f"Dimensions: {image.width} x {image.height} pixels"
            
            self.info_label.config(text=image_info)
            
            # Update status
            self.set_status(f"Showing preview: {filename}")
            
        except Exception as e:
            print(f"Error displaying image: {str(e)}")
            self.set_status(f"Error displaying image: {str(e)}")

    def show_progress(self, show=True, text="Processing..."):
        """Show or hide progress bar"""
        if show:
            self.progress_label.pack(side=tk.TOP, pady=(0, 5))
            self.progress_bar.pack(side=tk.TOP)
            self.progress_label.config(text=text)
            self.progress_var.set(0)
            self.root.update_idletasks()
        else:
            self.progress_label.pack_forget()
            self.progress_bar.pack_forget()
            self.progress_var.set(0)
            self.root.update_idletasks()

    def update_progress(self, value, text=None):
        """Update progress bar value and optionally text"""
        self.progress_var.set(value)
        if text:
            self.progress_label.config(text=text)
        self.root.update_idletasks()

    def upload_files(self):
        """Upload selected files to GitHub repository"""
        # Get selected files
        selection = self.file_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select files to upload")
            return

        try:
            self.show_progress(True, "Processing files for upload...")
            total_files = len(selection)
            uploaded_count = 0
            failed_files = []
            
            # First rename files to standardized format
            renamed_files = set()  # Keep track of successfully renamed files
            for i, index in enumerate(selection):
                filename = self.file_listbox.get(index)
                file_path = os.path.join(self.local_repo_path, self.labels_path, filename)
                
                self.update_progress(
                    ((i + 1) / total_files) * 33,  # First third of progress
                    f"Standardizing filename {i + 1} of {total_files}: {filename}"
                )
                
                try:
                    # Extract text from image using OCR
                    image = Image.open(file_path)
                    components = self.parse_label_text(image)
                    if not components:
                        failed_files.append(f"{filename} (couldn't extract components)")
                        continue
                    
                    product_name, variant, sku = components
                    new_name = f"{product_name}_{variant}_label_{sku}.png"
                    new_name = self.sanitize_filename(new_name)
                    new_path = os.path.join(self.local_repo_path, self.labels_path, new_name)
                    
                    # If the target path is different from the current path
                    if new_path != file_path:
                        # If a file with the new name exists but it's not our file
                        if os.path.exists(new_path):
                            os.remove(new_path)
                        # Rename the file
                        os.rename(file_path, new_path)
                        renamed_files.add(new_name)
                    else:
                        renamed_files.add(filename)
                    
                except Exception as e:
                    failed_files.append(f"{filename} ({str(e)})")
                    continue
            
            # Now upload the renamed files
            for i, filename in enumerate(renamed_files):
                try:
                    file_path = os.path.join(self.local_repo_path, self.labels_path, filename)
                    
                    self.update_progress(
                        33 + ((i + 1) / len(renamed_files)) * 67,  # Remaining progress
                        f"Uploading file {i + 1} of {len(renamed_files)}: {filename}"
                    )
                    
                    # Copy file to repository
                    repo_file_path = os.path.join(self.labels_path, filename)
                    
                    # Stage the file
                    self.git_command(["git", "add", repo_file_path],
                                   f"Failed to stage {filename}")
                    uploaded_count += 1
                    
                except Exception as e:
                    failed_files.append(f"{filename} ({str(e)})")
            
            if uploaded_count > 0:
                try:
                    # Commit all staged files
                    commit_message = f"Upload {uploaded_count} label{'s' if uploaded_count > 1 else ''}"
                    self.git_command(["git", "commit", "-m", commit_message],
                                   "Failed to commit files")
                    
                    # Push to GitHub
                    self.git_command(["git", "push", "origin", "main"],
                                   "Failed to push to GitHub")
                except Exception as e:
                    failed_files.append(f"Failed to sync with GitHub: {str(e)}")
                    # Try to recover by pulling latest changes
                    try:
                        self.git_command(["git", "pull", "--all"], "Failed to pull latest changes")
                    except:
                        pass
            
            # Refresh the file list
            self.refresh_files()
            
            # Show results
            message = f"Successfully uploaded {uploaded_count} file(s)"
            if failed_files:
                message += f"\n\nFailed to process {len(failed_files)} files:\n" + "\n".join(failed_files)
            
            if uploaded_count > 0:
                messagebox.showinfo("Upload Complete", message)
            else:
                messagebox.showerror("Upload Failed", message)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error uploading files: {str(e)}")
        finally:
            self.show_progress(False)

    def delete_files(self):
        """Handle file deletion using Git"""
        selected_indices = self.file_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Warning", "Please select files to delete")
            return
        
        selected_files = [self.file_listbox.get(i) for i in selected_indices]
        
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete these {len(selected_files)} file(s)?\n\n" +
            "\n".join(f"- {f}" for f in selected_files) + "\n\n" +
            "This action cannot be undone!",
            icon='warning'
        ):
            return
        
        try:
            # Pull latest changes
            self.set_status("Pulling latest changes...")
            self.git_command(["git", "pull"], "Failed to pull latest changes")
            
            # Remove files
            self.set_status("Removing files...")
            file_paths = [os.path.join(self.labels_path, f) for f in selected_files]
            
            self.git_command(["git", "rm"] + file_paths,
                           "Failed to remove files from Git")
            
            # Create commit
            commit_msg = f"Deleted {len(selected_files)} label file(s)\n\n" + \
                        "\n".join(f"- {f}" for f in selected_files)
            
            self.git_command(["git", "commit", "-m", commit_msg],
                           "Failed to create commit")
            
            # Push changes
            self.set_status("Pushing changes to GitHub...")
            self.git_command(["git", "push"], "Failed to push changes")
            
            messagebox.showinfo(
                "Success",
                f"Successfully deleted {len(selected_files)} file(s) from GitHub"
            )
            
            self.refresh_files()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete files: {str(e)}")

    def download_labels(self):
        """Download selected labels to a user-specified directory"""
        try:
            # Get selected items
            selected_indices = self.file_listbox.curselection()
            if not selected_indices:
                messagebox.showinfo("Info", "Please select labels to download")
                return

            # Ask user for download directory
            download_dir = filedialog.askdirectory(title="Select Download Directory")
            if not download_dir:
                return

            # Copy selected files from local repository
            copied_files = 0
            errors = []
            
            label_dir = os.path.join(self.local_repo_path, self.labels_path)
            
            for index in selected_indices:
                filename = self.file_listbox.get(index)
                src_path = os.path.join(label_dir, filename)
                
                if not os.path.exists(src_path):
                    errors.append(f"Could not find file: {filename}")
                    continue
                
                try:
                    # Copy file to destination
                    dst_path = os.path.join(download_dir, filename)
                    shutil.copy2(src_path, dst_path)
                    copied_files += 1
                    
                except Exception as e:
                    errors.append(f"Failed to copy {filename}: {str(e)}")

            # Show results
            if copied_files > 0:
                success_msg = f"Downloaded {copied_files} label file(s) to {download_dir}"
                if errors:
                    success_msg += "\n\nSome files had errors:\n" + "\n".join(errors)
                messagebox.showinfo("Download Complete", success_msg)
            else:
                error_msg = "No files were downloaded due to errors:\n\n" + "\n".join(errors)
                messagebox.showerror("Error", error_msg)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to download labels: {str(e)}")

    def rename_file(self):
        """Rename selected files using OCR"""
        selection = self.file_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select files to rename")
            return
        
        try:
            self.show_progress(True, "Processing files for renaming...")
            total_files = len(selection)
            renamed_count = 0
            failed_files = []
            
            # Pull latest changes first
            try:
                self.git_command(["git", "pull", "--all"], "Failed to pull latest changes")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to pull latest changes: {str(e)}")
                return
            
            for i, index in enumerate(selection):
                filename = self.file_listbox.get(index)
                file_path = os.path.join(self.local_repo_path, self.labels_path, filename)
                
                self.update_progress(
                    ((i + 1) / total_files) * 50,
                    f"Processing file {i + 1} of {total_files}: {filename}"
                )
                
                try:
                    # Extract text from image using OCR
                    image = Image.open(file_path)
                    
                    # Parse components
                    components = self.parse_label_text(image)
                    if not components:
                        failed_files.append(f"{filename} (couldn't extract components)")
                        continue
                    
                    product_name, variant, sku = components
                    new_name = f"{product_name}_{variant}_label_{sku}.png"
                    new_name = self.sanitize_filename(new_name)
                    new_path = os.path.join(self.local_repo_path, self.labels_path, new_name)
                    
                    # If the target path is different from the current path
                    if new_path != file_path:
                        try:
                            # First, stage the deletion of the old file
                            self.git_command(
                                ["git", "rm", "-f", "--cached", os.path.join(self.labels_path, filename)],
                                f"Failed to remove old file {filename} from git"
                            )
                            
                            # If a file with the new name exists, remove it from git and filesystem
                            if os.path.exists(new_path):
                                self.git_command(
                                    ["git", "rm", "-f", "--cached", os.path.join(self.labels_path, os.path.basename(new_path))],
                                    f"Failed to remove existing file {new_name} from git"
                                )
                                os.remove(new_path)
                            
                            # Now remove the old file from filesystem
                            os.remove(file_path)
                            
                            # Create the new file
                            shutil.copy2(file_path + ".tmp" if os.path.exists(file_path + ".tmp") else file_path, new_path)
                            
                            # Add the new file to git
                            self.git_command(
                                ["git", "add", os.path.join(self.labels_path, new_name)],
                                f"Failed to add new file {new_name}"
                            )
                            
                            renamed_count += 1
                            
                        except Exception as e:
                            failed_files.append(f"{filename} ({str(e)})")
                            continue
                    
                except Exception as e:
                    failed_files.append(f"{filename} ({str(e)})")
                    continue
            
            if renamed_count > 0:
                try:
                    # Commit the changes
                    commit_message = f"Rename {renamed_count} label{'s' if renamed_count > 1 else ''}"
                    self.git_command(
                        ["git", "commit", "-m", commit_message],
                        "Failed to commit renames"
                    )
                    
                    # Force push to GitHub to ensure our changes take precedence
                    self.git_command(
                        ["git", "push", "-f", "origin", "main"],
                        "Failed to push to GitHub"
                    )
                    
                    # Clean up any untracked files
                    self.git_command(
                        ["git", "clean", "-f", "-d"],
                        "Failed to clean untracked files"
                    )
                except Exception as e:
                    failed_files.append(f"Failed to sync with GitHub: {str(e)}")
            
            # Refresh the file list
            self.refresh_files()
            
            # Show results
            message = f"Successfully renamed {renamed_count} file(s)"
            if failed_files:
                message += f"\n\nFailed to rename {len(failed_files)} files:\n" + "\n".join(failed_files)
            
            if renamed_count > 0:
                messagebox.showinfo("Rename Complete", message)
            else:
                messagebox.showerror("Rename Failed", message)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error renaming files: {str(e)}")
        finally:
            self.show_progress(False)
    
    def parse_label_text(self, image):
        """Extract product name, variant, and SKU from label text"""
        try:
            # Extract text from image using OCR
            text = pytesseract.image_to_string(image)
            
            # Debug: Print the extracted text
            print("\nExtracted Text from Image:")
            print("------------------------")
            print(text)
            print("------------------------")
            
            # Split text into lines and clean them
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            print("\nCleaned Lines:")
            for line in lines:
                print(f"- {line}")
            
            # Find SKU (last line, should be 11-12 digits)
            sku = None
            if lines and re.match(r'^\d{11,12}$', lines[-1].strip()):
                sku = lines[-1].strip()
                # Ensure SKU is 12 digits, pad with 0 if needed
                sku = sku.zfill(12)
                print(f"\nFound SKU: {sku}")
                # Remove SKU line from further processing
                lines = lines[:-1]
            
            if not sku:
                print("\nERROR: No SKU found in text!")
                print("Looking for: 11-12 digit number in last line")
                print("Found lines:")
                for line in lines:
                    print(f"  - {line}")
                return None
            
            # Find variant (second to last line, before SKU)
            variant = None
            if lines:
                # Try standard variant format first (XXXVX)
                for line in lines:
                    if re.search(r'\b[A-Z]{3,4}V\d+\b', line):
                        variant = line.strip()
                        break
                
                # If no standard variant found, use the line before SKU
                if not variant and len(lines) >= 1:
                    variant = lines[-1].strip()
                    # Remove variant line from further processing
                    lines = lines[:-1]
            
            if not variant:
                print("\nERROR: No variant found in text!")
                print("Looking for: Line before the SKU")
                print("Found lines:")
                for line in lines:
                    print(f"  - {line}")
                return None
            
            # Remaining lines form the product name
            product_name_parts = []
            for line in lines:
                if line.lower() != 'label':  # Skip "Label" line
                    product_name_parts.append(line.strip())
            
            product_name = " ".join(product_name_parts)
            
            if not product_name:
                print("\nERROR: No product name found!")
                print("Looking for: Text lines before variant")
                print("Found lines:")
                for line in lines:
                    print(f"  - {line}")
                return None
            
            print(f"\nFound Product Name: {product_name}")
            
            # Clean up product name
            product_name = product_name.replace('_', ' ').strip()
            
            # Final validation
            if not all([product_name, variant, sku]):
                print("\nERROR: Missing required components!")
                print(f"Product Name: {'✓' if product_name else '✗'} ({product_name if product_name else 'Not found'})")
                print(f"Variant: {'✓' if variant else '✗'} ({variant if variant else 'Not found'})")
                print(f"SKU: {'✓' if sku else '✗'} ({sku if sku else 'Not found'})")
                return None
            
            print("\nSuccessfully extracted all components:")
            print(f"Product Name: {product_name}")
            print(f"Variant: {variant}")
            print(f"SKU: {sku}")
            
            return product_name.strip(), variant.strip(), sku.strip()
            
        except Exception as e:
            print(f"\nERROR: Exception while parsing text: {str(e)}")
            print("Full text being parsed:")
            print(text)
            return None
    
    def sanitize_filename(self, filename):
        """Clean filename to be valid"""
        # Replace invalid characters
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, '_')
        
        # Remove leading/trailing spaces and dots
        filename = filename.strip('. ')
        
        # Ensure filename is not too long (Windows limit is 255)
        if len(filename) > 255:
            name, ext = os.path.splitext(filename)
            filename = name[:255-len(ext)] + ext
            
        return filename

    def get_file_hash(self, filepath):
        """Calculate SHA-256 hash of a file"""
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def extract_numbers(self, filename):
        """Extract all numbers from filename"""
        return ''.join(re.findall(r'\d+', filename))

    def extract_12digit_numbers(self, filename):
        """Extract all 12-digit numbers from filename"""
        return re.findall(r'\d{12}', filename)

    def show_duplicates(self):
        """Find and display files that share the same 12-digit UPC"""
        # Dictionary to store files by UPC
        upc_files = {}
        
        # Regular expression to find 12 consecutive digits
        upc_pattern = re.compile(r'\d{12}')
        
        # Get all files from the labels directory
        label_dir = os.path.join(self.local_repo_path, self.labels_path)
        if not os.path.exists(label_dir):
            messagebox.showerror("Error", "Labels directory not found")
            return
            
        # Group files by UPC
        for filename in os.listdir(label_dir):
            if os.path.isfile(os.path.join(label_dir, filename)):
                match = upc_pattern.search(filename)
                if match:
                    upc = match.group()
                    if upc not in upc_files:
                        upc_files[upc] = []
                    upc_files[upc].append(filename)
        
        # Filter for UPCs with multiple files
        duplicates = {upc: files for upc, files in upc_files.items() if len(files) > 1}
        
        if not duplicates:
            messagebox.showinfo("No Duplicates", "No files sharing the same UPC were found.")
            return
        
        # Create a new window to display duplicates
        dup_window = tk.Toplevel(self.root)
        dup_window.title("Duplicate UPCs")
        dup_window.geometry("1200x800")
        dup_window.configure(bg='#ecf0f1')
        
        # Create main container with padding
        main_container = ttk.Frame(dup_window, padding="10")
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Add a header with explanation and count
        total_dupes = sum(len(files) for files in duplicates.values())
        header_text = f"Found {len(duplicates)} UPCs with duplicate files ({total_dupes} total files)\n"
        header_text += "Select files to preview and delete unwanted duplicates"
        header = ttk.Label(main_container, text=header_text, style='Header.TLabel')
        header.pack(fill=tk.X, pady=(0, 10))
        
        # Create left panel for the tree
        left_panel = ttk.Frame(main_container)
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Create treeview with columns
        tree = ttk.Treeview(left_panel, columns=('UPC', 'Filename', 'Size'), show='headings')
        tree.heading('UPC', text='UPC')
        tree.heading('Filename', text='Filename')
        tree.heading('Size', text='Size')
        tree.column('UPC', width=120)
        tree.column('Filename', width=500)
        tree.column('Size', width=100)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(left_panel, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack the treeview and scrollbar
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create right panel for preview
        right_panel = ttk.Frame(main_container, width=400)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(10, 0))
        right_panel.pack_propagate(False)
        
        # Preview header
        preview_label = ttk.Label(right_panel, 
                               text="Label Preview\n(Select a file to preview)",
                               style='Header.TLabel')
        preview_label.pack(fill=tk.X, pady=(0, 10))
        
        # Image preview
        preview_frame = ttk.Frame(right_panel)
        preview_frame.pack(fill=tk.BOTH, expand=True)
        
        image_label = ttk.Label(preview_frame)
        image_label.pack(fill=tk.BOTH, expand=True)
        
        # File info label
        info_label = ttk.Label(right_panel, wraplength=380)
        info_label.pack(fill=tk.X, pady=(10, 0))
        
        # Add files to treeview, grouped by UPC
        for upc, files in sorted(duplicates.items()):
            # Add UPC as parent
            upc_node = tree.insert('', 'end', values=(upc, f"{len(files)} files", ""), tags=('upc',))
            
            # Add files under UPC
            for filename in sorted(files):
                file_path = os.path.join(label_dir, filename)
                size = os.path.getsize(file_path)
                size_str = f"{size:,} bytes"
                tree.insert(upc_node, 'end', values=(upc, filename, size_str), tags=('file',))
        
        # Configure tag colors
        tree.tag_configure('upc', background='#d5e8f9')
        
        # Delete button - made larger and more prominent
        delete_btn = ttk.Button(right_panel, 
                             text="Delete Selected Files",
                             style='Danger.TButton',
                             command=lambda: self.delete_selected_duplicates(tree))
        delete_btn.pack(pady=10)
        
        def on_select(event):
            """Handle selection in the treeview"""
            selected_items = tree.selection()
            if not selected_items:
                image_label.config(image='')
                info_label.config(text='')
                return
            
            # Get the selected item
            item = selected_items[0]
            
            # Check if it's a file (not a UPC group)
            if 'file' in tree.item(item)['tags']:
                filename = tree.item(item)['values'][1]
                file_path = os.path.join(label_dir, filename)
                
                try:
                    # Load and display image
                    image = Image.open(file_path)
                    
                    # Resize for preview while maintaining aspect ratio
                    display_size = (380, 380)
                    image.thumbnail(display_size, Image.Resampling.LANCZOS)
                    
                    photo = ImageTk.PhotoImage(image)
                    image_label.config(image=photo)
                    image_label.image = photo  # Keep a reference
                    
                    # Update info
                    file_size = os.path.getsize(file_path)
                    info_label.config(
                        text=f"Filename: {filename}\n"
                             f"Size: {file_size:,} bytes\n"
                             f"Dimensions: {image.width} x {image.height} pixels"
                    )
                except Exception as e:
                    messagebox.showerror("Error", f"Error loading preview: {str(e)}")
        
        tree.bind('<<TreeviewSelect>>', on_select)
        
        def delete_selected_duplicates(tree):
            """Delete selected files from both local repository and GitHub"""
            selected_items = tree.selection()
            if not selected_items:
                messagebox.showinfo("Info", "Please select files to delete")
                return
            
            # Collect files to delete
            files_to_delete = []
            for item in selected_items:
                # Only process file items (not UPC groups)
                if 'file' in tree.item(item)['tags']:
                    filename = tree.item(item)['values'][1]
                    files_to_delete.append(filename)
            
            if not files_to_delete:
                messagebox.showinfo("Info", "Please select individual files to delete (not UPC groups)")
                return
            
            # Confirm deletion
            if not messagebox.askyesno("Confirm Delete", 
                                     f"Are you sure you want to delete {len(files_to_delete)} file(s)?\n"
                                     "These files will be permanently deleted from both local and GitHub repositories."):
                return
            
            # Delete files
            deleted_count = 0
            errors = []
            
            try:
                # First, stage all deletions
                for filename in files_to_delete:
                    try:
                        file_path = os.path.join(self.local_repo_path, self.labels_path, filename)
                        if os.path.exists(file_path):
                            # Remove from local repository
                            os.remove(file_path)
                            # Stage the deletion in git
                            self.git_command(
                                ["git", "rm", "-f", os.path.join(self.labels_path, filename)],
                                f"Failed to stage deletion of {filename}"
                            )
                            deleted_count += 1
                    except Exception as e:
                        errors.append(f"Failed to delete {filename}: {str(e)}")
                
                if deleted_count > 0:
                    try:
                        # Commit the changes
                        commit_message = f"Delete {deleted_count} duplicate label{'s' if deleted_count > 1 else ''}"
                        self.git_command(
                            ["git", "commit", "-m", commit_message],
                            "Failed to commit deletions"
                        )
                        
                        # Push the changes to GitHub
                        self.git_command(
                            ["git", "push", "origin", "main"],
                            "Failed to push changes to GitHub"
                        )
                    except Exception as e:
                        errors.append(f"Failed to sync with GitHub: {str(e)}")
                        # Try to recover by pulling latest changes
                        try:
                            self.git_command(["git", "pull", "--all"], "Failed to pull latest changes")
                        except:
                            pass
            except Exception as e:
                errors.append(f"Error during deletion process: {str(e)}")
            
            # Show results
            if deleted_count > 0:
                # Refresh the main file list
                self.refresh_files()
                
                # Close the duplicates window
                dup_window.destroy()
                
                # Show success message
                message = f"Successfully deleted {deleted_count} file(s) from both local and GitHub repositories"
                if errors:
                    message += "\n\nErrors:\n" + "\n".join(errors)
                messagebox.showinfo("Delete Complete", message)
            else:
                message = "No files were deleted"
                if errors:
                    message += "\n\nErrors:\n" + "\n".join(errors)
                messagebox.showerror("Delete Failed", message)
        
        # Replace the old delete function with our new one
        delete_btn.config(command=lambda: delete_selected_duplicates(tree))
        
    def setup_repository(self):
        """Setup local repository"""
        try:
            # Create directory in user's AppData/Local folder
            app_data = os.path.join(os.environ['LOCALAPPDATA'], 'LabelManager')
            repo_dir = os.path.join(app_data, 'Repository')
            
            # Create app directory if it doesn't exist
            if not os.path.exists(app_data):
                os.makedirs(app_data)
            
            # Remove existing repo if it exists
            if os.path.exists(repo_dir):
                try:
                    shutil.rmtree(repo_dir)
                except PermissionError:
                    # If can't remove, try to work with existing repo
                    self.local_repo_path = repo_dir
                    # Try to pull latest changes
                    try:
                        self.git_command(["git", "pull"], "Failed to pull latest changes")
                    except:
                        pass
                    return True
            
            try:
                os.makedirs(repo_dir)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create repository directory: {str(e)}")
                return False
            
            self.local_repo_path = repo_dir
            
            # Clone the repository with depth=1 to speed up initial clone
            try:
                clone_url = f"https://github.com/{self.repo_owner}/{self.repo_name}.git"
                self.set_status(f"Cloning repository from {clone_url}...")
                
                # First try a fresh clone
                result = self.git_command(
                    ["git", "clone", "--no-single-branch", "--depth=1", clone_url, "."],
                    "Failed to clone repository"
                )
                
                if result:
                    # Then fetch all remaining history
                    self.set_status("Fetching complete repository history...")
                    self.git_command(
                        ["git", "fetch", "--unshallow"],
                        "Failed to fetch complete history"
                    )
                    
                    # Make sure we're on the main branch
                    self.git_command(
                        ["git", "checkout", "main"],
                        "Failed to checkout main branch"
                    )
                    
                    # Pull latest changes
                    self.git_command(
                        ["git", "pull", "--all"],
                        "Failed to pull latest changes"
                    )
            except Exception as e:
                messagebox.showerror("Error", f"Failed to clone repository: {str(e)}")
                return False
            
            # Create labels directory if it doesn't exist
            labels_dir = os.path.join(self.local_repo_path, self.labels_path)
            if not os.path.exists(labels_dir):
                os.makedirs(labels_dir)
            
            return True
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to setup repository: {str(e)}")
            return False

    def show_debug_dialog(self, title, text):
        """Show a dialog with debug information"""
        debug_window = tk.Toplevel(self.root)
        debug_window.title(title)
        debug_window.geometry("600x400")
        
        # Add text widget
        text_widget = tk.Text(debug_window, wrap=tk.WORD, padx=10, pady=10)
        text_widget.pack(fill=tk.BOTH, expand=True)
        
        # Add scrollbar
        scrollbar = tk.Scrollbar(text_widget)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Configure scrollbar
        text_widget.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=text_widget.yview)
        
        # Insert text
        text_widget.insert(tk.END, text)
        text_widget.config(state=tk.DISABLED)
        
        # Add close button
        close_button = tk.Button(debug_window, text="Close", command=debug_window.destroy)
        close_button.pack(pady=10)

    def __del__(self):
        """Cleanup temporary repository"""
        if self.local_repo_path and os.path.exists(self.local_repo_path):
            try:
                shutil.rmtree(self.local_repo_path)
            except:
                pass

def main():
    root = tk.Tk()
    root.title("Label Manager")
    
    # Set style
    style = ttk.Style()
    style.theme_use('clam')  # or 'vista' on Windows
    
    app = GitHubLabelManager(root)
    root.mainloop()

if __name__ == "__main__":
    main()
