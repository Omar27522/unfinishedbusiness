import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Optional, Dict, Any, Callable
import os
from PIL import Image, ImageTk
import pyautogui
from ..config import ConfigManager
from .window_manager import WindowManager
from ..barcode_generator import BarcodeGenerator, LabelData

class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        
        # Initialize window tracking
        self.app_windows = []  # Track all windows
        self.app_windows.append(self)  # Include main window
        
        self.config_manager = ConfigManager()
        self.window_manager = WindowManager()
        self.barcode_generator = BarcodeGenerator(self.config_manager.settings)
        
        self._setup_fonts()
        self._setup_variables()
        self._load_icons()
        self._create_tooltip_class()
        self._create_main_window()
        
        # Bind focus event to main window
        self.bind("<FocusIn>", lambda e: self._on_window_focus(self))

    def _setup_fonts(self):
        """Configure default fonts"""
        self.default_font = ('TkDefaultFont', 11)
        self.button_font = ('TkDefaultFont', 11, 'normal')
        self.entry_font = ('TkDefaultFont', 11)
        self.label_font = ('TkDefaultFont', 11)
        self.view_files_font = ('TkDefaultFont', 12, 'bold')

        self.option_add('*Font', self.default_font)
        self.option_add('*Button*Font', self.button_font)
        self.option_add('*Entry*Font', self.entry_font)
        self.option_add('*Label*Font', self.label_font)

    def _setup_variables(self):
        """Initialize tkinter variables"""
        self.font_size_large = tk.IntVar(value=self.config_manager.settings.font_size_large)
        self.font_size_medium = tk.IntVar(value=self.config_manager.settings.font_size_medium)
        self.barcode_width = tk.IntVar(value=self.config_manager.settings.barcode_width)
        self.barcode_height = tk.IntVar(value=self.config_manager.settings.barcode_height)
        self.always_on_top = tk.BooleanVar(value=self.config_manager.settings.always_on_top)
        self.transparency_level = tk.DoubleVar(value=self.config_manager.settings.transparency_level)
        self.png_count = tk.StringVar(value=f"Labels: {self.config_manager.settings.label_counter}")

    def _load_icons(self):
        """Load icons for buttons"""
        # Create a simple batch icon using a PhotoImage
        self.batch_icon = tk.PhotoImage(width=16, height=16)
        # Create a simple spreadsheet-like icon using pixels
        data = """
        ................
        .##############.
        .#            #.
        .#############..
        .#            #.
        .#############..
        .#            #.
        .#############..
        .#            #.
        .#############..
        .#            #.
        .#############..
        .#            #.
        .##############.
        ................
        ................
        """
        # Put the data into the image
        for y, line in enumerate(data.split()):
            for x, c in enumerate(line):
                if c == '#':
                    self.batch_icon.put('#666666', (x, y))

    def _create_tooltip_class(self):
        """Create a tooltip class for button hints"""
        class ToolTip(object):
            def __init__(self, widget, text):
                self.widget = widget
                self.text = text
                self.tooltip = None
                self.widget.bind('<Enter>', self.enter)
                self.widget.bind('<Leave>', self.leave)
                self.widget.bind('<ButtonPress>', self.leave)

            def enter(self, event=None):
                x, y, _, _ = self.widget.bbox("insert")
                x += self.widget.winfo_rootx() + 25
                y += self.widget.winfo_rooty() + 20
                self.tooltip = tk.Toplevel(self.widget)
                self.tooltip.wm_overrideredirect(True)
                self.tooltip.wm_geometry(f"+{x}+{y}")
                label = tk.Label(self.tooltip, text=self.text, 
                               justify='left',
                               background="#ffffe0", 
                               relief='solid', 
                               borderwidth=1,
                               font=("TkDefaultFont", "8", "normal"))
                label.pack()

            def leave(self, event=None):
                if self.tooltip:
                    self.tooltip.destroy()
                    self.tooltip = None

        self.CreateToolTip = ToolTip

    def _create_styled_button(self, parent, text, command, width=8, has_icon=False, icon=None, tooltip_text="", color_scheme=None):
        """Create a styled button with hover effect"""
        if color_scheme is None:
            color_scheme = {
                'bg': '#3498db',  # Default blue
                'fg': 'white',
                'hover_bg': '#2980b9',
                'active_bg': '#2473a6'
            }

        btn = tk.Button(
            parent,
            text=text,
            command=command,
            width=width,
            font=('TkDefaultFont', 10, 'bold'),  # Increased font size and made bold
            relief='raised',
            bg=color_scheme['bg'],
            fg=color_scheme['fg'],
            activebackground=color_scheme['active_bg'],
            activeforeground='white',
            bd=1,  # Border width
            padx=10,  # Horizontal padding
            pady=4,   # Vertical padding
        )
        
        if has_icon and icon:
            btn.config(image=icon, compound=tk.LEFT)

        # Add hover effect
        def on_enter(e):
            if not (hasattr(btn, 'is_active') and btn.is_active):
                btn['background'] = color_scheme['hover_bg']
                btn['cursor'] = 'hand2'

        def on_leave(e):
            if not (hasattr(btn, 'is_active') and btn.is_active):
                btn['background'] = color_scheme['bg']
                btn['cursor'] = ''

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)

        # Add tooltip
        if tooltip_text:
            self.CreateToolTip(btn, tooltip_text)

        return btn

    def _create_main_window(self):
        """Create and setup the main application window"""
        # Configure main window
        self.title("Label Maker")
        self.minsize(450, 200)
        
        # Set window icon
        icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'assets', 'icon_64.png')
        if os.path.exists(icon_path):
            # Load the icon
            icon = tk.PhotoImage(file=icon_path)
            # Set both the window icon and the taskbar icon
            self.iconphoto(True, icon)
            
            # For Windows taskbar icon
            try:
                import ctypes
                myappid = 'labelmaker.app.ver3.0'  # Arbitrary string
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
            except Exception:
                pass  # Fail silently if Windows-specific call fails
        
        # Center window on screen
        self.update_idletasks()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        x = (screen_width - self.winfo_width()) // 2
        y = (screen_height - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")
        
        # Prevent window resizing
        self.resizable(False, False)
        
        # Bind window close event
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # Create main frame with comfortable padding
        self.main_frame = tk.Frame(self, padx=8, pady=5, bg='SystemButtonFace')
        self.main_frame.pack(expand=True, fill=tk.BOTH)
        
        # Create top control frame
        self._create_top_control_frame()
        
        # Create control buttons frame (Reset)
        self._create_control_frame()
        
        # Create input fields
        self._create_input_fields()
        
        # Create action buttons frame
        self._create_action_buttons()
        
        # Add separator
        ttk.Separator(self.main_frame, orient='horizontal').grid(
            row=8, column=0, columnspan=2, sticky=tk.EW, pady=10
        )

    def _create_top_control_frame(self):
        """Create top control frame with Always on Top, Settings, and Labels Count buttons"""
        top_control_frame = tk.Frame(self.main_frame, bg='SystemButtonFace')
        top_control_frame.grid(row=0, column=0, columnspan=2, sticky="ew", pady=5)  # Increased padding
        
        # Create a sub-frame for the buttons to ensure proper horizontal alignment
        button_frame = tk.Frame(top_control_frame, bg='SystemButtonFace')
        button_frame.pack(side=tk.LEFT, padx=8)  # Increased padding
        
        # Color schemes for different buttons
        always_on_top_colors = {
            'bg': '#e74c3c',  # Red
            'fg': 'white',
            'hover_bg': '#c0392b',
            'active_bg': '#2ecc71'  # Green when active
        }
        
        settings_colors = {
            'bg': '#9b59b6',  # Purple
            'fg': 'white',
            'hover_bg': '#8e44ad',
            'active_bg': '#7d3c98'
        }
        
        labels_count_colors = {
            'bg': '#2ecc71',  # Green
            'fg': 'white',
            'hover_bg': '#27ae60',
            'active_bg': '#219a52'
        }
        
        # Always on Top button with toggle styling
        self.always_on_top = tk.BooleanVar(value=False)
        self.always_on_top_btn = self._create_styled_button(
            button_frame,
            text="Always on Top",
            command=self.toggle_always_on_top,
            width=12,
            tooltip_text="Keep window on top of other windows",
            color_scheme=always_on_top_colors
        )
        self.always_on_top_btn.is_active = False
        self.always_on_top_btn.pack(side=tk.LEFT, padx=3)  # Increased padding
        
        # Settings button with matching style
        settings_btn = self._create_styled_button(
            button_frame,
            text="Settings",
            command=self.show_settings,
            width=8,
            tooltip_text="Configure application settings",
            color_scheme=settings_colors
        )
        settings_btn.pack(side=tk.LEFT, padx=3)  # Increased padding
        
        # Labels count button
        self.png_count_btn = self._create_styled_button(
            button_frame,
            text="",  # Text will be set by textvariable
            command=self._select_output_directory,
            width=12,
            tooltip_text="Click to change labels output directory",
            color_scheme=labels_count_colors
        )
        self.png_count_btn.config(textvariable=self.png_count)
        self.png_count_btn.pack(side=tk.LEFT, padx=3)  # Increased padding

    def toggle_always_on_top(self):
        """Toggle the always on top state"""
        self.always_on_top.set(not self.always_on_top.get())
        if self.always_on_top.get():
            self.always_on_top_btn.is_active = True
            self.always_on_top_btn.config(
                bg='#2ecc71',  # Bright green when active
                activebackground='#27ae60',  # Darker green when clicked
                relief='sunken'
            )
            self.attributes('-topmost', True)
            self.lift()
            self.focus_force()
        else:
            self.always_on_top_btn.is_active = False
            self.always_on_top_btn.config(
                bg='#e74c3c',  # Back to red
                activebackground='#c0392b',
                relief='raised'
            )
            self.attributes('-topmost', False)

    def check_topmost_state(self):
        """Periodically check and enforce topmost state"""
        if self.always_on_top.get():
            self.attributes('-topmost', True)
            self.lift()
        self.after(1000, self.check_topmost_state)  # Check every second

    def _create_control_frame(self):
        """Create control buttons frame (Reset)"""
        control_frame = tk.Frame(self.main_frame, bg='SystemButtonFace')
        control_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Reset button with vibrant red theme
        reset_btn = tk.Button(control_frame,
            text="Reset",
            width=8,
            bg='#e74c3c',  # Bright red
            activebackground='#c0392b',  # Darker red when clicked
            fg='white',
            command=self.clear_inputs
        )
        reset_btn.pack(side=tk.LEFT, padx=5)

    def _create_input_fields(self):
        """Create input fields"""
        self.inputs = {}
        labels = [
            ("Product Name Line 1", "name_line1"),
            ("Line 2 (optional)", "name_line2"),
            ("Variant", "variant"),
            ("UPC Code (12 digits)", "upc_code")
        ]

        def on_input_focus(event):
            """Enable Always on Top when user focuses on any input field"""
            if not self.always_on_top.get():
                self.always_on_top.set(True)
                self.always_on_top_btn.config(
                    bg='#2ecc71',  # Bright green when active
                    activebackground='#27ae60',  # Darker green when clicked
                    relief='sunken'
                )
                self.attributes('-topmost', True)
            
            # If preview window is open, select all text in the field
            if hasattr(self, 'preview_window') and self.preview_window and self.preview_window.winfo_exists():
                event.widget.select_range(0, tk.END)
                event.widget.icursor(tk.END)

        def on_input_click(event):
            """Handle mouse click in input field"""
            if hasattr(self, 'preview_window') and self.preview_window and self.preview_window.winfo_exists():
                event.widget.select_range(0, tk.END)
                event.widget.icursor(tk.END)

        def validate_upc(action, value_if_allowed):
            """Only allow integers in UPC field and ensure exactly 12 digits"""
            if action == '1':  # Insert action
                if not value_if_allowed:  # Allow empty field
                    return True
                # Only allow digits and ensure length doesn't exceed 12
                if not value_if_allowed.isdigit():
                    return False
                return len(value_if_allowed) <= 12
            return True

        def validate_variant(action, value_if_allowed):
            """Prevent numbers at the start of variant field"""
            if action == '1':  # Insert action
                if not value_if_allowed:  # Allow empty field
                    return True
                # Check if the first character is a digit
                if value_if_allowed[0].isdigit():
                    return False
                return True
        
        for idx, (label_text, key) in enumerate(labels):
            # Label
            label = tk.Label(self.main_frame,
                text=label_text,
                anchor="e",
                width=20,
                bg='SystemButtonFace'
            )
            label.grid(row=idx+2, column=0, padx=5, pady=3, sticky="e")
            
            # Entry
            if key == "upc_code":
                vcmd = (self.register(validate_upc), '%d', '%P')
                entry = tk.Entry(self.main_frame,
                    width=25,
                    relief='sunken',
                    bg='white',
                    validate='key',
                    validatecommand=vcmd
                )
            elif key == "variant":
                vcmd = (self.register(validate_variant), '%d', '%P')
                entry = tk.Entry(self.main_frame,
                    width=25,
                    relief='sunken',
                    bg='white',
                    validate='key',
                    validatecommand=vcmd
                )
            else:
                entry = tk.Entry(self.main_frame,
                    width=25,
                    relief='sunken',
                    bg='white'
                )
            
            # Bind events
            entry.bind("<FocusIn>", on_input_focus)
            entry.bind("<Button-1>", on_input_click)  # Handle mouse click
            
            # Add context menu
            self._add_context_menu(entry)
            
            entry.grid(row=idx+2, column=1, padx=5, pady=3, sticky="w")
            self.inputs[key] = entry

    def _create_action_buttons(self):
        """Create action buttons frame"""
        button_frame = tk.Frame(self.main_frame, bg='SystemButtonFace')
        button_frame.grid(row=6, column=0, columnspan=2, pady=5)
        
        # Preview button with vibrant blue theme
        preview_btn = self._create_styled_button(
            button_frame,
            text="Preview",
            command=self.preview_label,
            width=10,
            tooltip_text="Show a preview of the label"
        )
        preview_btn.pack(side=tk.LEFT, padx=2)
        
        # View Files button with vibrant purple theme
        view_files_btn = self._create_styled_button(
            button_frame,
            text="View Files",
            command=self.view_directory_files,
            width=10,
            tooltip_text="Open the directory viewer"
        )
        view_files_btn.pack(side=tk.LEFT, padx=2)

    def _create_tooltip(self, widget, text):
        """Create a tooltip for a widget"""
        def enter(event):
            x, y, _, _ = widget.bbox("insert")
            x += widget.winfo_rootx() + 25
            y += widget.winfo_rooty() + 20
            
            # Creates a toplevel window
            self.tooltip = tk.Toplevel(widget)
            self.tooltip.wm_overrideredirect(True)
            self.tooltip.wm_geometry(f"+{x}+{y}")
            
            label = ttk.Label(self.tooltip, text=text, background="#ffffe0", relief='solid', borderwidth=1)
            label.pack()
            
        def leave(event):
            if hasattr(self, 'tooltip'):
                self.tooltip.destroy()
                
        widget.bind('<Enter>', enter)
        widget.bind('<Leave>', leave)

    def _add_context_menu(self, widget):
        """Add right-click context menu to widget"""
        menu = tk.Menu(widget, tearoff=0)
        menu.add_command(label="Copy", 
                        command=lambda: widget.event_generate('<<Copy>>'))
        menu.add_command(label="Paste", 
                        command=lambda: widget.event_generate('<<Paste>>'))
        menu.add_command(label="Cut", 
                        command=lambda: widget.event_generate('<<Cut>>'))
        menu.add_separator()
        menu.add_command(label="Select All", 
                        command=lambda: widget.select_range(0, tk.END))
        
        widget.bind("<Button-3>", 
                   lambda e: menu.tk_popup(e.x_root, e.y_root))

    def _toggle_always_on_top(self):
        """Toggle always on top state"""
        self.always_on_top.set(not self.always_on_top.get())
        if self.always_on_top.get():
            self.always_on_top_btn.config(
                bg='#2ecc71',  # Bright green when active
                activebackground='#27ae60',  # Darker green when clicked
                relief='sunken'
            )
            # Focus main window when enabling always on top
            self._on_window_focus(self)
        else:
            self.always_on_top_btn.config(
                bg='SystemButtonFace',
                activebackground='SystemButtonFace',
                relief='raised'
            )
            self.attributes('-topmost', False)
        
        # Update window state
        self.config_manager.settings.always_on_top = self.always_on_top.get()
        self.config_manager.save_settings()

    def _update_window_settings(self):
        """Update window settings based on current state"""
        self.window_manager.set_window_on_top(
            self, 
            self.always_on_top.get()
        )
        self.window_manager.make_draggable(self)

    def _update_png_count(self):
        """Update PNG count label"""
        if self.config_manager.settings.last_directory:
            count = len([f for f in os.listdir(self.config_manager.settings.last_directory)
                        if f.lower().endswith('.png')])
            self.config_manager.settings.label_counter = count
            self.png_count.set(f"Labels: {count}")
            self.config_manager.save_settings()

    def _select_output_directory(self):
        """Select output directory"""
        last_dir = self.config_manager.settings.last_directory
        directory = filedialog.askdirectory(
            title="Select where to save labels",
            initialdir=last_dir if last_dir and os.path.exists(last_dir) else None
        )
        if directory:
            self.config_manager.settings.last_directory = directory
            self.config_manager.save_settings()
            self._update_png_count()
            # Also open the directory viewer
            self.view_directory_files()

    def preview_label(self):
        """Show label preview"""
        label_data = self._get_label_data()
        if not label_data:
            return

        label_image = self.barcode_generator.generate_label(label_data)
        if label_image:
            if hasattr(self, 'preview_window') and self.preview_window:
                self.preview_window.destroy()
                if self.preview_window in self.app_windows:
                    self.app_windows.remove(self.preview_window)

            # Create new window
            self.preview_window = tk.Toplevel(self)
            self.preview_window.title("Label Preview")
            self.preview_window.transient(self)
            self.app_windows.append(self.preview_window)
            
            # Bind focus events
            self.preview_window.bind("<FocusIn>", lambda e: self._on_window_focus(self.preview_window))
            
            # Give initial focus
            self.preview_window.focus_set()
            
            # Create a frame for the image
            self.preview_frame = ttk.Frame(self.preview_window)
            self.preview_frame.pack(padx=5, pady=5)
            
            # Create label for the image
            self.preview_label = ttk.Label(self.preview_frame)
            self.preview_label.pack()
            
            # Update the preview with initial image
            self._update_preview(label_data)

            # Create button frame
            button_frame = ttk.Frame(self.preview_window)
            button_frame.pack(pady=5)

            # Save Label button with styling
            save_btn = tk.Button(button_frame, 
                text="Save Label",
                command=lambda: [self.save_label(), check_label_saved()],
                bg='#e3f2fd',   # Light blue background
                activebackground='#bbdefb',  # Slightly darker when clicked
                font=('TkDefaultFont', 9, 'bold'),
                relief='raised'
            )
            save_btn.pack(side=tk.LEFT, padx=3)

            # Add hover effect
            def on_save_enter(e):
                save_btn['bg'] = '#bbdefb'
            def on_save_leave(e):
                save_btn['bg'] = '#e3f2fd'
            save_btn.bind("<Enter>", on_save_enter)
            save_btn.bind("<Leave>", on_save_leave)

            # Function to check if label is saved and update button states
            def check_label_saved():
                # Create filename with label information
                product_name = label_data.name_line1
                if label_data.name_line2:
                    product_name = f"{product_name} {label_data.name_line2}"
                product_name = "".join(c for c in product_name if c.isalnum() or c in "- _")
                variant = "".join(c for c in label_data.variant if c.isalnum() or c in "- _")
                filename = f"{product_name}_{variant}_label_{label_data.upc_code}.png"
                
                # Check if directory exists and file exists
                if (self.config_manager.settings.last_directory and 
                    os.path.exists(self.config_manager.settings.last_directory)):
                    filepath = os.path.join(self.config_manager.settings.last_directory, filename)
                    if os.path.exists(filepath):
                        open_btn.config(state='normal', bg='#fff3e0')
                        print_btn.config(state='normal', bg='#e8f5e9')
                        return
                
                # If file doesn't exist, disable buttons
                open_btn.config(state='disabled', bg='#f5f5f5')
                print_btn.config(state='disabled', bg='#f5f5f5')

            # Open Label button
            def open_label():
                # Create filename with label information
                product_name = label_data.name_line1
                if label_data.name_line2:
                    product_name = f"{product_name} {label_data.name_line2}"
                product_name = "".join(c for c in product_name if c.isalnum() or c in "- _")
                variant = "".join(c for c in label_data.variant if c.isalnum() or c in "- _")
                filename = f"{product_name}_{variant}_label_{label_data.upc_code}.png"
                filepath = os.path.join(self.config_manager.settings.last_directory, filename)

                try:
                    # Open the saved file with the default program
                    os.startfile(filepath)
                    
                    # Close the preview window
                    self.preview_window.destroy()
                    self.preview_window = None
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to open label: {str(e)}")

            open_btn = tk.Button(button_frame,
                text="Open Label",
                command=open_label,
                bg='#f5f5f5',  # Disabled gray background
                state='disabled',  # Start disabled
                activebackground='#ffe0b2',  # Slightly darker when clicked
                font=('TkDefaultFont', 9, 'bold'),
                relief='raised'
            )
            open_btn.pack(side=tk.LEFT, padx=3)

            # Add hover effect
            def on_open_enter(e):
                if open_btn['state'] == 'normal':
                    open_btn['bg'] = '#ffe0b2'
            def on_open_leave(e):
                if open_btn['state'] == 'normal':
                    open_btn['bg'] = '#fff3e0'
            open_btn.bind("<Enter>", on_open_enter)
            open_btn.bind("<Leave>", on_open_leave)

            # Print Label button
            def print_label():
                # Check if label has been saved
                if not self.config_manager.settings.last_directory or not os.path.exists(self.config_manager.settings.last_directory):
                    messagebox.showwarning("Save Required", "Please save the label before printing.")
                    return
                
                # Create filename with label information
                product_name = label_data.name_line1
                if label_data.name_line2:
                    product_name = f"{product_name} {label_data.name_line2}"
                product_name = "".join(c for c in product_name if c.isalnum() or c in "- _")
                variant = "".join(c for c in label_data.variant if c.isalnum() or c in "- _")
                filename = f"{product_name}_{variant}_label_{label_data.upc_code}.png"
                
                # Check if the file exists
                if not os.path.exists(filepath):
                    messagebox.showwarning("Save Required", "Please save the label before printing.")
                    return

                try:
                    # Open the saved file with the default program
                    os.startfile(filepath, "print")
                    
                    # Wait a moment for the print dialog to appear and press Enter
                    self.preview_window.after(1000, lambda: pyautogui.press('enter'))
                    
                    # Close the preview window after printing
                    self.preview_window.after(2000, lambda: [
                        self.preview_window.destroy(),
                        setattr(self, 'preview_window', None)
                    ])
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to print: {str(e)}")

            print_btn = tk.Button(button_frame,
                text="Print Label",
                command=print_label,
                bg='#f5f5f5',  # Disabled gray background
                state='disabled',  # Start disabled
                activebackground='#c8e6c9',  # Slightly darker when clicked
                font=('TkDefaultFont', 9, 'bold'),
                relief='raised'
            )
            print_btn.pack(side=tk.LEFT, padx=3)

            # Add hover effect
            def on_print_enter(e):
                if print_btn['state'] == 'normal':
                    print_btn['bg'] = '#c8e6c9'
            def on_print_leave(e):
                if print_btn['state'] == 'normal':
                    print_btn['bg'] = '#e8f5e9'
            print_btn.bind("<Enter>", on_print_enter)
            print_btn.bind("<Leave>", on_print_leave)

            # Set window properties
            self.window_manager.set_window_on_top(self.preview_window, self.always_on_top.get())
            self.window_manager.make_draggable(self.preview_window)

    def _update_preview(self, label_data):
        """Update the preview window with new label data"""
        label_image = self.barcode_generator.generate_label(label_data)
        if label_image:
            # Resize for display
            display_img = label_image.resize(
                (self.config_manager.settings.LABEL_WIDTH // 2,
                 self.config_manager.settings.LABEL_HEIGHT // 2),
                Image.Resampling.LANCZOS
            )
            
            photo = ImageTk.PhotoImage(display_img)
            self.preview_label.configure(image=photo)
            self.preview_label.image = photo  # Keep reference

    def save_label(self):
        """Generate and save label"""
        # Get label data first to avoid asking for directory if data is invalid
        label_data = self._get_label_data()
        if not label_data:
            return

        # Get directory from Labels button or ask user
        directory = self.config_manager.settings.last_directory
        if not directory or not os.path.exists(directory):
            directory = filedialog.askdirectory(title="Select where to save labels")
            if not directory:
                return
            # Update and save the last used directory
            self.config_manager.settings.last_directory = directory
            self.config_manager.save_settings()
            self._update_png_count()

        label_image = self.barcode_generator.generate_label(label_data)
        if label_image:
            # Create filename with all label information
            # Combine name_line1 and name_line2 if name_line2 exists
            product_name = label_data.name_line1
            if label_data.name_line2:
                product_name = f"{product_name} {label_data.name_line2}"
            
            # Replace any characters that might cause issues in filenames
            product_name = "".join(c for c in product_name if c.isalnum() or c in "- _")
            variant = "".join(c for c in label_data.variant if c.isalnum() or c in "- _")
            
            filename = f"{product_name}_{variant}_label_{label_data.upc_code}.png"
            filepath = os.path.join(directory, filename)
            label_image.save(filepath)
            messagebox.showinfo("Success", f"Label saved as {filename}")
            self._update_png_count()  # Update count after saving new label

    def show_settings(self):
        """Show settings window"""
        # If window exists, destroy it first
        if hasattr(self, 'settings_window') and self.settings_window:
            try:
                self.settings_window.destroy()
            except:
                pass
            self.settings_window = None

        # Create new settings window
        self.settings_window = tk.Toplevel(self)
        self.settings_window.title("Settings")
        self.settings_window.transient(self)
        self.settings_window.grab_set()  # Make window modal
        
        def close_settings():
            if hasattr(self, 'settings_window') and self.settings_window:
                self.settings_window.grab_release()
                self.settings_window.destroy()
                self.settings_window = None
        
        # Bind close event
        self.settings_window.protocol("WM_DELETE_WINDOW", close_settings)
        
        # Give initial focus
        self.settings_window.focus_set()
    
        # Font size settings
        ttk.Label(self.settings_window, text="Large Font Size:").grid(row=0, column=0, padx=5, pady=2)
        ttk.Entry(self.settings_window, textvariable=self.font_size_large).grid(row=0, column=1, padx=5, pady=2)
    
        ttk.Label(self.settings_window, text="Medium Font Size:").grid(row=1, column=0, padx=5, pady=2)
        ttk.Entry(self.settings_window, textvariable=self.font_size_medium).grid(row=1, column=1, padx=5, pady=2)
    
        # Barcode size settings
        ttk.Label(self.settings_window, text="Barcode Width:").grid(row=2, column=0, padx=5, pady=2)
        ttk.Entry(self.settings_window, textvariable=self.barcode_width).grid(row=2, column=1, padx=5, pady=2)
    
        ttk.Label(self.settings_window, text="Barcode Height:").grid(row=3, column=0, padx=5, pady=2)
        ttk.Entry(self.settings_window, textvariable=self.barcode_height).grid(row=3, column=1, padx=5, pady=2)
    
        # Window settings
        ttk.Checkbutton(self.settings_window, text="Always on Top", 
                       variable=self.always_on_top).grid(row=4, column=0, columnspan=2, pady=5)

        # Add CSV button
        csv_frame = ttk.Frame(self.settings_window)
        csv_frame.grid(row=5, column=0, columnspan=2, pady=5)
        
        csv_btn = tk.Button(csv_frame, text="CSV", font=('TkDefaultFont', 10, 'bold'),
                          bg='#FFD700', fg='black', width=10, height=1,
                          command=self._create_batch_labels)
        csv_btn.pack(pady=5)
        
        # Create tooltip for CSV button
        self._create_tooltip(csv_btn, "Create multiple labels from a CSV file")
    
        # Save button
        save_btn = ttk.Button(self.settings_window, text="Save", 
                      command=lambda: self._save_settings(self.settings_window))
        save_btn.grid(row=6, column=0, columnspan=2, pady=10)

    def _save_settings(self, settings_window):
        """Save settings and close settings window"""
        # Save all settings
        self.config_manager.settings.font_size_large = self.font_size_large.get()
        self.config_manager.settings.font_size_medium = self.font_size_medium.get()
        self.config_manager.settings.barcode_width = self.barcode_width.get()
        self.config_manager.settings.barcode_height = self.barcode_height.get()
        self.config_manager.settings.always_on_top = self.always_on_top.get()
        self.config_manager.settings.transparency_level = self.transparency_level.get()
        
        # Save to file and update window state
        self.config_manager.save_settings()
        self.window_manager.set_window_on_top(self, self.always_on_top.get())
        
        # Close the window properly
        if settings_window:
            settings_window.grab_release()
            settings_window.destroy()
            self.settings_window = None

    def _get_label_data(self) -> Optional[LabelData]:
        """Get label data from input fields"""
        # Check required fields
        name_line1 = self.inputs["name_line1"].get().strip()
        variant = self.inputs["variant"].get().strip()
        upc = self.inputs["upc_code"].get().strip()

        # Validate required fields
        if not name_line1:
            messagebox.showerror("Error", "Product Name Line 1 is required")
            return None
        if not variant:
            messagebox.showerror("Error", "Variant is required")
            return None
        if not upc:
            messagebox.showerror("Error", "UPC Code is required")
            return None
        
        # Validate UPC code length
        if len(upc) != 12:
            messagebox.showerror("Error", "UPC Code must be exactly 12 digits")
            return None

        # Line 2 is optional
        name_line2 = self.inputs["name_line2"].get().strip()

        return LabelData(
            name_line1=name_line1,
            name_line2=name_line2,
            variant=variant,
            upc_code=upc
        )

    def clear_inputs(self):
        """Clear all input fields"""
        for entry in self.inputs.values():
            entry.delete(0, tk.END)

    def view_directory_files(self):
        """Display files from the output directory in a new window"""
        # If file window exists and is valid, just focus it
        if hasattr(self, 'file_window') and self.file_window and self.file_window.winfo_exists():
            self.window_manager.focus_window(self.file_window)
            return

        if not self.config_manager.settings.last_directory or not os.path.exists(self.config_manager.settings.last_directory):
            # Ask for directory if none is set or if it doesn't exist
            self._select_output_directory()
            return

        self.file_window = tk.Toplevel(self)
        self.file_window.title("View Files")
        self.file_window.transient(self)
        self.app_windows.append(self.file_window)
        
        # Bind focus events
        self.file_window.bind("<FocusIn>", lambda e: self._on_window_focus(self.file_window))
        
        # Give initial focus
        self.file_window.focus_set()
        self.file_window.minsize(450, 200)

        # Create main content frame
        main_content = tk.Frame(self.file_window)
        main_content.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        # Create top frame for controls
        top_frame = tk.Frame(main_content)
        top_frame.pack(fill=tk.X, padx=0, pady=1)

        # Add Pin (Always on Top) button
        window_always_on_top = tk.BooleanVar(value=False)
        window_top_btn = tk.Button(top_frame, text="Pin", bg='#C71585', relief='raised', width=8)

        def toggle_window_on_top():
            current_state = window_always_on_top.get()
            self.file_window.attributes('-topmost', current_state)
            if current_state:
                self.file_window.lift()
                window_top_btn.config(
                    text="Pin",
                    bg='#90EE90',  # Light green when active
                    relief='sunken'
                )
            else:
                window_top_btn.config(
                    text="Pin",
                    bg='#C71585',  # Velvet color when inactive
                    relief='raised'
                )

        window_top_btn.config(
            command=lambda: [window_always_on_top.set(not window_always_on_top.get()), 
                           toggle_window_on_top()]
        )
        window_top_btn.pack(side=tk.LEFT, padx=2)

        # Add Label Count display
        label_count_label = tk.Label(
            top_frame,
            text="",  # Will be set by update_file_list
            font=('TkDefaultFont', 10, 'bold'),
            fg='#2ecc71'  # Green text
        )
        label_count_label.pack(side=tk.LEFT, padx=10)

        # Add Magnifier button
        is_magnified = tk.BooleanVar(value=False)
        magnifier_btn = tk.Button(top_frame, text="🔍", bg='#C71585', relief='raised', width=3,
                                font=('TkDefaultFont', 14))

        def toggle_magnification():
            current_state = is_magnified.get()
            new_size = 16 if current_state else 9
            listbox.configure(font=('TkDefaultFont', new_size))
            if current_state:
                h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
                listbox.configure(wrap=tk.NONE)
            else:
                h_scrollbar.pack_forget()
                listbox.configure(wrap=tk.CHAR)
            magnifier_btn.config(
                bg='#90EE90' if current_state else '#C71585',
                relief='sunken' if current_state else 'raised'
            )

        magnifier_btn.config(
            command=lambda: [is_magnified.set(not is_magnified.get()), 
                           toggle_magnification()]
        )
        magnifier_btn.pack(side=tk.LEFT, padx=2)

        # Create search frame
        search_frame = tk.Frame(main_content)
        search_frame.pack(fill=tk.X, padx=0, pady=6)

        tk.Label(search_frame, text="Find:", 
                font=('TkDefaultFont', 11, 'bold')).pack(side=tk.LEFT, padx=(4,2))
        search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=search_var, 
                              font=('TkDefaultFont', 11))
        
        # Auto-select contents when entry gets focus
        def select_all(event):
            event.widget.select_range(0, tk.END)
            return "break"  # Prevents default behavior
            
        search_entry.bind('<FocusIn>', select_all)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=6)
        search_entry.focus_set()

        # Create list frame
        list_frame = tk.Frame(main_content)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=0, pady=1)

        # Add listbox with scrollbars
        listbox = tk.Listbox(list_frame, height=4, font=('TkDefaultFont', 9))
        listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        v_scrollbar = tk.Scrollbar(list_frame)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        h_scrollbar = tk.Scrollbar(list_frame, orient=tk.HORIZONTAL)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)

        listbox.config(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        v_scrollbar.config(command=listbox.yview)
        h_scrollbar.config(command=listbox.xview)

        def update_file_list(*args):
            """Update the listbox based on search text"""
            search_text = search_var.get().lower()
            listbox.delete(0, tk.END)
            try:
                files = os.listdir(self.config_manager.settings.last_directory)
                png_files = [f for f in files if f.lower().endswith('.png')]
                for file in sorted(png_files):
                    if search_text in file.lower():
                        listbox.insert(tk.END, file)
                if len(png_files) == 0:
                    listbox.insert(tk.END, "No PNG files found")
                    label_count_label.config(text="No Labels", fg='#e74c3c')  # Red text for no labels
                else:
                    listbox.selection_clear(0, tk.END)
                    listbox.selection_set(0)
                    listbox.see(0)
                    label_count_label.config(text=f"Labels: {len(png_files)}", fg='#2ecc71')  # Green text for label count
            except Exception as e:
                messagebox.showerror("Error", f"Failed to read directory: {str(e)}")

        search_var.trace('w', update_file_list)

        # Initial file list update
        update_file_list()

        # Add double-click binding
        listbox.bind('<Double-Button-1>', lambda e: preview_selected_file())

        def open_selected_file():
            """Open the selected file"""
            selection = listbox.curselection()
            if selection:
                file_name = listbox.get(selection[0])
                file_path = os.path.join(self.config_manager.settings.last_directory, 
                                       file_name)
                try:
                    # Open the saved file with the default program
                    os.startfile(file_path)
                    
                    # Close the preview window
                    self.file_window.destroy()
                    self.file_window = None
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to open file: {str(e)}")

        def print_selected_file():
            """Print the selected file directly"""
            selection = listbox.curselection()
            if not selection:
                messagebox.showinfo("Info", "Please select a file to print.")
                return

            file_name = listbox.get(selection[0])
            file_path = os.path.join(self.config_manager.settings.last_directory, 
                                   file_name)
            try:
                os.startfile(file_path, "print")
                self.file_window.after(1000, lambda: pyautogui.press('enter'))
            except Exception as e:
                messagebox.showerror("Error", f"Failed to print: {str(e)}")

        def preview_selected_file():
            """Preview the selected image file"""
            selection = listbox.curselection()
            if not selection:
                messagebox.showinfo("Info", "Please select an image to preview.")
                return

            file_name = listbox.get(selection[0])
            file_path = os.path.join(self.config_manager.settings.last_directory, 
                                   file_name)

            try:
                img = Image.open(file_path)
                display_width = min(400, img.width)
                ratio = display_width / img.width
                display_height = int(img.height * ratio)

                img = img.resize((display_width, display_height), Image.Resampling.LANCZOS)
                img_tk = ImageTk.PhotoImage(img)

                preview_window = tk.Toplevel(self.file_window)
                preview_window.title(f"File Preview: {file_name}")
                preview_window.transient(self.file_window)

                # Create preview frame
                preview_frame = tk.Frame(preview_window)
                preview_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

                # Display image
                img_label = tk.Label(preview_frame, image=img_tk)
                img_label.image = img_tk
                img_label.pack(pady=5)

                # Add buttons
                button_frame = tk.Frame(preview_frame)
                button_frame.pack(pady=5)

                tk.Button(button_frame, text="Print", command=print_selected_file,
                         bg='#e8f5e9', activebackground='#c8e6c9',
                         font=('TkDefaultFont', 9, 'bold'),
                         relief='raised').pack(side=tk.LEFT, padx=3)

                tk.Button(button_frame, text="Open", command=open_selected_file,
                         bg='#e3f2fd', activebackground='#bbdefb',
                         font=('TkDefaultFont', 9, 'bold'),
                         relief='raised').pack(side=tk.LEFT, padx=3)

                # Make preview window draggable
                self.window_manager.make_draggable(preview_window)

            except Exception as e:
                messagebox.showerror("Error", f"Failed to preview image: {str(e)}")

        # Create bottom button frame
        button_frame = tk.Frame(main_content)
        button_frame.pack(fill=tk.X, padx=2, pady=2)

        # Add buttons with styling
        tk.Button(button_frame, text="Open", command=open_selected_file,
                 bg='#e3f2fd', activebackground='#bbdefb',
                 font=('TkDefaultFont', 9, 'bold'),
                 relief='raised',
                 width=15,
                 height=2
                ).pack(side=tk.LEFT, padx=2)

        tk.Button(button_frame, text="Print", command=print_selected_file,
                 bg='#e8f5e9', activebackground='#c8e6c9',
                 font=('TkDefaultFont', 9, 'bold'),
                 relief='raised',
                 width=15,
                 height=2
                ).pack(side=tk.LEFT, padx=2)

        tk.Button(button_frame, text="Preview", command=preview_selected_file,
                 bg='#fff3e0', activebackground='#ffe0b2',
                 font=('TkDefaultFont', 9, 'bold'),
                 relief='raised',
                 width=15,
                 height=2
                ).pack(side=tk.LEFT, padx=2)

        # Add GitHub icon button
        icon_data = '''
        iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAAWQAA
        AFkBqp2phgAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAJESURBVDiNjZO9a1NRHIaf
        c8+9N/feJM1HY5LaFquLiCAOUrDgJl1EdHERnMTVyUHBf8DBxck/wEEHFRRxEZQiDorFQYtLqkixTZrkJrk3
        997z8zChMWiwfqcDL7zP+z7wCq01/0dz0/Mm8AA4ChjAGvBU+8XjP+WJv4T3gGfABaD7R+gT8FAI7s5N5U78
        AUwDL4Bx4NnG9g7LGzUKhRJCCIyYzUgmSSadxPeaC8C1uancq7ZBAL4Cg0qp5M3Hz3j3YQnP8zF0AyklSimE
        gOFslkuTE0gpk8Bz4DJA5AD8CIwrpZLXHjxk4f0iYRjiui4t10UpRRiGrBaLvF5cpFqtWsCZdkVmG3wK9AMU
        SiXmF94ThCGO4+C6LkopjDCg5Hn4YYhpGGxvbZHP5zEMI92G9wAngI1qrY7neQRBgOM4eEFA0/exEZimSRRF
        KKXQWlOv1RgcHNwFjgJY7VYXgO+maeJ5Hq1WC9/3sUwTwzCwLAulFFpr6vU6WmtarRau6/4CHgI/hRDrgAaS
        pmXSbDYJggCpFEIIDAAhBEopGo0GWmvCMKRer4cxxnngE/DtYBfuCCFeaqUujwwPs7y6SqvVwhACKSVSSoQQ
        RFGE1hrHcUgYxjvgDHBXwN5h6gKuCMH9kydOMjY6yreNDba2t2k0m0RRhGmaJBIJkokEA5kMJ8bGsG0b4BZw
        HcgdTOEWcAe4CwwBCSB2kN0EVoA54DHw8WCkw0d0FrgKTAJZIAmsA/PAG+0XT/0bSjf5V5tNoNsAAAAASUVO
        RK5CYII=
        '''
        # Convert base64 icon to PhotoImage
        import base64
        from io import BytesIO
        from PIL import Image, ImageTk
        
        icon_data = base64.b64decode(icon_data.replace('\n', '').strip())
        image = Image.open(BytesIO(icon_data))
        github_icon = ImageTk.PhotoImage(image)

        tk.Button(button_frame, image=github_icon,
                 width=30,
                 height=30,
                 bg='#24292e',  # GitHub dark color
                 activebackground='#1b1f23',  # Darker shade for hover
                 command=self._open_github_manager
                ).pack(side=tk.RIGHT, padx=2)

    def _open_github_manager(self):
        """Open GitHub Label Manager window"""
        try:
            from src.github_label_manager import GitHubLabelManager
            if not hasattr(self, 'github_manager') or not tk.Toplevel.winfo_exists(self.github_manager):
                self.github_manager = GitHubLabelManager(self)
                self.github_manager.focus_force()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open GitHub Label Manager: {str(e)}")

    def on_close(self):
        """Handle window close event"""
        self.config_manager.save_settings()
        self.quit()

    def run(self):
        """Start the application"""
        try:
            self.mainloop()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to start application: {str(e)}")
            raise

    def _on_window_focus(self, focused_window):
        """Handle window focus to manage stacking order"""
        # Lower all windows
        for window in self.app_windows:
            if window.winfo_exists():  # Check if window still exists
                if isinstance(window, tk.Tk):  # Main window
                    window.attributes('-topmost', self.always_on_top.get())
                else:  # Child windows
                    window.attributes('-topmost', False)
        
        # Raise the focused window
        if focused_window != self or self.always_on_top.get():  # Don't set main window topmost unless Always on Top is enabled
            focused_window.attributes('-topmost', True)
        focused_window.lift()

    def _cleanup_window(self, window):
        """Clean up window from tracking list"""
        if window in self.app_windows:
            self.app_windows.remove(window)

    def _create_batch_labels(self):
        """Open CSV file and create batch labels"""
        csv_file = filedialog.askopenfilename(
            title="Select CSV File",
            filetypes=[("CSV files", "*.csv")]
        )
        if csv_file:
            from main import create_batch_labels
            create_batch_labels(csv_file, self)
